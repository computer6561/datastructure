#include <iostream>
#include<cstring>
#include<algorithm>

using namespace std;

int main(int argc, char const *argv[])
{
	char str[] = "Hii, I am sunil kumar studing in rec";
	char *ptr;

	ptr = strtok(str," ");

	while(ptr!=NULL){
		cout<<ptr<<endl;
	    ptr = strtok(NULL," ");
	}



	return 0;
}