#include<stdio.h>
void readElements(char a[][10],int n,int m){
	int startRow = 0,endRow=n-1,startCol=0,endCol=m-1;
	char ch;
	int j=1;
   while(startRow<=endRow && startCol<=endCol){
   	  if(j%2==0)
   	  	ch= '0';
   	  else
   	  	ch = 'x';
   	  j++;
   	   //print top row
	   for (int i = startCol; i <=endCol; ++i)
	   {
	   	 a[startRow][i]=ch;
	   }
	   startRow++;

	   //print right column
	   for (int i = startRow; i <=endRow; ++i)
	   {
	   	 a[i][endCol]=ch;
	   }
	   endCol--;

	     //print bottom row
        if(startRow<=endRow){
        	 for (int i = endCol; i>=startCol; --i)
			   {
			   	 a[endRow][i]=ch;
			   }
	     
        }
         endRow--;
	   //print left column
        if(startCol<=endCol){
        	 for (int i = endRow; i>=startRow; --i)
			   {
			   	 a[i][startCol]=ch;
			   }
        }
        startCol++;
	    
   }
}
void printElements(char a[][10],int n,int m){
	for (int i = 0; i <n; ++i)
	{
		for (int j =0; j < m; ++j)
		{
			printf("%c  ",a[i][j]);
		}
		printf("\n");
	}
}


int main(int argc, char const *argv[])
{
	char a[10][10];
	int n, m;
	scanf("%d %d",&n,&m);
	//create spiral pattern
	readElements(a,n,m);
	//print spiral pattern
    printElements(a,n,m);
    

  printf("\n");	
	return 0;
}