#include <iostream>
#include<cstring>
using namespace std;

void rotateStr(char a[],int k){
	int i = strlen(a);

	while(i>=0){
		a[i+k] = a[i];
		--i;
	}
	i = strlen(a);
	int s=0;
	int j = i-k;
	while(s<k){
   
     a[s++] =  a[j++];
	}
	a[i-k]='\0';

}

int main(int argc, char const *argv[])
{
	char a[] = "Hello world";
    int k=3;
    rotateStr(a,k);
	cout<<a<<endl;
	return 0;
}