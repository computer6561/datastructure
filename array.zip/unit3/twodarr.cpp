#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
    char a[][4] = {{'a','b','c','\0'},{'d','e','f','\0'}};
    
    cout<<a[0][0]<<endl;
    cout<<a[0]<<endl;
     cout<<a[1]<<endl;

	return 0;
}