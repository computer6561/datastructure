#include<stdio.h>
void readElements(int a[][10],int n,int m){
	for (int i = 0; i <n; ++i)
	{
		for (int j =0; j < m; ++j)
		{
			scanf("%d",&a[i][j]);
		}
	}
}
void printElements(int a[][10],int n,int m){
	for (int i = 0; i <n; ++i)
	{
		for (int j =0; j < m; ++j)
		{
			printf("%d  ",a[i][j]);
		}
		printf("\n");
	}
}
void printCircle(int a[][10],int n,int m){
   int startRow = 0,endRow=n-1,startCol=0,endCol=m-1;
   while(startRow<=endRow && startCol<=endCol){
   	   //print top row
	   for (int i = startCol; i <=endCol; ++i)
	   {
	   	 printf("%d  ",a[startRow][i]);
	   }
	   startRow++;

	   //print right column
	   for (int i = startRow; i <=endRow; ++i)
	   {
	   	 printf("%d  ",a[i][endCol]);
	   }
	   endCol--;

	     //print bottom row
        if(startRow<=endRow){
        	 for (int i = endCol; i>=startCol; --i)
			   {
			   	 printf("%d  ",a[endRow][i]);
			   }
	     
        }
         endRow--;
	   //print left column
        if(startCol<=endCol){
        	 for (int i = endRow; i>=startRow; --i)
			   {
			   	 printf("%d  ",a[i][startCol]);
			   }
        }
        startCol++;
	    
   }
  

}

int main(int argc, char const *argv[])
{
	int a[10][10];
	int n, m;
	scanf("%d %d",&n,&m);
	//Read array
	readElements(a,n,m);
	//print array
    printElements(a,n,m);
    //printCircle
    printCircle(a,n,m);

  printf("\n");	
	return 0;
}