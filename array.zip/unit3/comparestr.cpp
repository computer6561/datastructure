#include <iostream>
#include<cstring>
#include<algorithm>
using namespace std;

bool compare(string str1,string str2){
     return str1.length()>str2.length();
}


int main(int argc, char const *argv[])
{
	string str[] = {"kumar","Abhishek","Sunil","Raushan"};

	sort(str,str+4,compare);

    for (int i = 0; i <4; ++i)
    {
       cout<<str[i]<<endl;
    }

	return 0;
}