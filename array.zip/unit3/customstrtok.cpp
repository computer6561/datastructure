#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;

char * myStrTok(char *str, char ch){
   static char *str1;
   char str2[100];
   static int i = 0;

   if(str!=NULL)
   	  str1 = str;
   	else{
        cout<"hii";
   	}
     while(str+i++ !='\0')
          str2[i] = str[i];
   cout<<str2<<endl;   
}

int main(int argc, char const *argv[])
{
    char *str = "I am sunil kumar studing in computer science and engineering";

    char *ptr = myStrTok(str,' ');
    cout<<ptr<endl;
	return 0;
}