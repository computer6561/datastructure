#include<stdio.h>
#include<string.h>

int isCombination(char str1[],char str2[]){
     char check[100]={0};

     int n = strlen(str1);
     int m = strlen(str2);
     if(n==m){
       for (int i = 0; i <n; ++i)
       {
       	 check[i] = 1;
       }
       for (int i = 0; i <n; ++i)
       {
       	 for (int j = 0; j <n; ++j)
       	 {
       	 	//printf("%c %c %d \n",str1[i],str2[j],check[i] );
       	 	if(str1[i]==str2[j] && check[i]==1){
       	 		check[i]=0;

       	 	}
       	 }
       }
        for (int i = 0; i <n; ++i)
       {
       //	printf("T: %c %c %d \n",str1[i],str2[i],check[i] );
       	 if(check[i]==1)
       	 	return 0;
       }
       return 1;
     }else
       return 0;
}


int main(int argc, char const *argv[])
{
	char str1[] = "sunpil";
	char str2[] = "sunlip";
         if(isCombination(str1,str2))
         	printf("It is combination.\n");
         else
         	printf("It is not combination.\n");
	return 0;
}