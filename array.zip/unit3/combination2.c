#include<stdio.h>
#include<string.h>

int isCombination(char str1[],char str2[]){
	int freq1[100] = {0};
	int freq2[100] = {0};

	int n = strlen(str1);
	int m = strlen(str2);
	if(n==m){
        for (int i = 0; i < n; ++i)
        {
        	freq1[str1[i]- 'A']++;
        	freq1[str2[i]- 'A']--;
        }
         for (int i = 0; i <58; ++i)
        {
        	if(freq1[i]!=0)
        		return 0;
        }
        return 1;
	}else
	  return 0;

}



int main(int argc, char const *argv[])
{
	char str1[] = "sunksL";
	char str2[] = "sunLks";
         if(isCombination(str1,str2))
         	printf("It is combination.\n");
         else
         	printf("It is not combination.\n");
	return 0;
}