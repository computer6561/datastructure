#include<stdio.h>

void printElements(int a[][10],int n,int m){
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}
}

void searchElements(int a[][10],int n,int m,int key){
	int i=0,j=m-1;
printElements(a,n,m);
	while(i<n && j>=0){
		if(a[i][j]==key){
			printf("Element is located at {%d,%d}.\n",i,j);
			return;
		}else if(a[i][j]<key)
			i++;
		else if(a[i][j]>key)
			j--;
	}

	printf("Element is not found.\n");
}

int main(int argc, char const *argv[])
{
	int a[10][10];
	int n,m,key;
	scanf("%d %d",&n,&m);
	printf("\nEnter elements: \n");
	for (int i = 0; i <n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			scanf("%d",&a[i][j]);
		}
	}
	printf("Please enter key : \n");
	scanf("%d",&key);
	searchElements(a,n,m,key);
	return 0;
}